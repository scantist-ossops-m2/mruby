Pure Ruby Extension Example
=========

This is an example gem which implements a pure Ruby extension.
