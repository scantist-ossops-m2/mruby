class Time
  def sunday?;  wday == 0 end
  def monday?;  wday == 1 end
  def tuesday?;  wday == 2 end
  def wednesday?;  wday == 3 end
  def thursday?;  wday == 4 end
  def friday?;  wday == 5 end
  def saturday?;  wday == 6 end
end
