##
# StandardError ISO Test

assert('StandardError', '15.2.23') do
  assert_equal Class, StandardError.class
end
